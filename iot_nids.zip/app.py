from flask import Flask, render_template
import sqlite3
import threading
from packet_sniffer import start_sniffing

app = Flask(__name__)

sniffer_thread = threading.Thread(target=start_sniffing, daemon=True)
sniffer_thread.start()

@app.route('/')
def index():
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("SELECT * FROM logs ORDER BY id DESC LIMIT 50")
    logs = c.fetchall()
    conn.close()
    return render_template('index.html', logs=logs)

if __name__ == "__main__":
    app.run(debug=True)
