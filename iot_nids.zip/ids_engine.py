import random

def analyze_packet(packet_summary):
    suspicious_keywords = ['FTP', 'Telnet', 'Nmap', 'Malformed']
    for word in suspicious_keywords:
        if word.lower() in packet_summary.lower():
            return "Intrusion"
    return "Normal" if random.random() > 0.1 else "Intrusion"
